import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route,Routes } from 'react-router-dom';
import BookingList from './Components/BookingList';
import Booking from './Components/Booking';
import EditBooking from './Components/EditBooking';
import Header from './Components/Header';
import Footer from './Components/Footer';
import { Provider } from 'react-redux';
import Appstore from './Redux/Store';
import BookingConfirmation from './Components/BookingConfirmation';
import {ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';   
import RegisterUser from './Components/RegisterUser';
import LoginUser from './Components/LoginUser';
import EditUser from './Components/EditUser';
import LogOutUser from './Components/LogOut';
import UserList from './Components/UserList';

function App() {
  return (
    <div className='App'>
      <Provider store={Appstore}>
    <BrowserRouter>
    <Header></Header>
    <Routes>
      <Route path='/' element={<Booking/>}></Route>
      <Route path='BookingList' element={<BookingList/>}></Route>
      <Route path='EditBooking/:id' element={<EditBooking/>}></Route>
      <Route path='EditUser/:userId' element={<EditUser />} />
      <Route path='RegisterUser' element={<RegisterUser/>}></Route>
      <Route path='LoginUser' element={<LoginUser/>}></Route>
      <Route path='LogOutUser' element={<LogOutUser/>}></Route>
      <Route path='UserList' element={<UserList/>}></Route>
      
      <Route path='BookingConfirmation' element={<BookingConfirmation/>}></Route>
      
    </Routes>
    <Footer></Footer>
    </BrowserRouter>
    </Provider>
    <ToastContainer></ToastContainer>

    </div>
  );
}

export default App;
