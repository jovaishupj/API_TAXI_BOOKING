const Footer = () => {
    return (
        <footer>
        <p>&copy; {new Date().getFullYear()} City Ride</p>        
      </footer>      );
}
 
export default Footer;