import { useEffect, useState } from "react";
import { connect } from "react-redux";
import { GetAllLocation } from "../Redux/ActionCreator";
import { useNavigate } from "react-router-dom";

const BookingConfirmation = (props) => {

    const navigate = useNavigate();

    useEffect(() => {
        console.log(props.bookingstate.booking);
    }, [])
    const handleSubmit = (e) => {
        navigate("/");
    }
    return (
        <div className="row">
            <div className="offset-lg-2 col-lg-8 pt-4">
                <div className="card">
                    <div className="card-header">
                        <h2>Booking Confirmation</h2>
                    </div>
                    <div className="card-body">
                        <div className="form-group">
                            <label style={{ float: "none" }}>Booking Number :</label>
                            <label style={{ float: "none" }}>{props.bookingstate.booking.bookingId}</label>
                        </div>

                        <div className="form-group">
                            <label style={{ float: "none" }}>Pickup Location :</label>
                            <label style={{ float: "none" }}>{props.bookingstate.booking.location.locationName}</label>
                        </div>
                        <div className="form-group">
                            <label style={{ float: "none" }}>Pickup Time :</label>
                            <label style={{ float: "none" }}>{props.bookingstate.booking.pickupTime}</label>
                        </div>
                        <div className="form-group">
                            <label style={{ float: "none" }}>Status :</label>
                            <label style={{ float: "none" }}>{props.bookingstate.booking.status}</label>
                        </div>

                    </div>
                    <div className="card-footer">
                        <button className="btn btn-success" onClick={handleSubmit} type="submit"> Back to Booking</button>
                    </div>

                </div>

            </div>
        </div>

    );
}

const mapStatetoProps = (state) => {
    return {
        bookingstate: state.booking
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        GetAllPickupLocation: () => dispatch(GetAllLocation())

    }
}


export default connect(mapStatetoProps, mapDispatchtoProps)(BookingConfirmation);

