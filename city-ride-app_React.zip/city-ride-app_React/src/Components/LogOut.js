import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const LogOutUser = () => {
    const navigate = useNavigate();
    useEffect(() => {
        localStorage.clear();    
        navigate('/LoginUser')
    }, []);
    return ( <h2>Logout Successfully</h2> );
}
 
export default LogOutUser;