import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

const Header = () => {
  const [menuvisible, menuvisiblechange] = useState(true);
  const [adminuser, adminuserchange] = useState(false);
  const location = useLocation();
  const navigate=useNavigate();

  useEffect(() => {

    if (location.pathname == '/RegisterUser' || location.pathname == '/LoginUser') {
        menuvisiblechange(false);
    } else {
        let username = localStorage.getItem('UserName') != null ? localStorage.getItem('UserName').toString() : '';
        if (username === '') {
            navigate('/LoginUser');
        }
        menuvisiblechange(true);
        let userrole = localStorage.getItem('Role') != null ? localStorage.getItem('Role').toString() : '';
        if (userrole === 'Admin') {
            adminuserchange(true);
        }else{
            adminuserchange(false);
        }

    }

}, [location]);
    return (

      <div>
        { menuvisible &&

        <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/BookingList">Booking List</Link>
          </li>
          
          {adminuser &&
              <li>
              <Link to="/UserList">User List</Link>
            </li>
           }
          <li>
            <Link style={{float:'right'}} to="/LogOutUser">Log Out</Link>
          </li>
        </ul>
      </nav>
}
      </div>
      );
}
 
export default Header;