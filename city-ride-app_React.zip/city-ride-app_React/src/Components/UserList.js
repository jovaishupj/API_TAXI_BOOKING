import { TextField, TableCell, TableContainer, TableHead, Table, TableRow, TableBody, Button, TablePagination } from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { connect, useDispatch } from "react-redux";
import { GetUserList } from "../Redux/ActionCreator";


const UserList = (props) => {
    const Columns = [
        { id: "userId", Name: "User Id" },
        { id: "userName", Name: "User Name" },
        { id: "roleName", Name: "Role Name" },
        { id: "userPhone", Name: "Phone" },
        { id: "userEmail", Name: "Email" },
        { id: "Action", Name: "Action" }
    ]
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [rowperpage, rowperpagechange] = useState(2);
    const [page, pagechange] = useState(0);

    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('');
    const [filter, setFilter] = useState({ bookingId: '', creationDate: '', status: '' });


    const handleRequestSort = (property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };



    const handlepagechange = (event, newpage) => {
        pagechange(newpage);
    }

    const handlerowperpagechange = (event) => {
        rowperpagechange(+event.target.value);
        pagechange(0);
    }
    useEffect(() => {
        dispatch(GetUserList());
        console.log(props.UserState.Userlist)

    }, []);
    const handleEdit = (userId) => {

        navigate('/EditUser/' + userId);
    }


    return (
        <div className="col-lg-12">
            <div style={{ margin: '1%', borderStyle: 'outset' }}>

                <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow style={{ backgroundColor: '#F48FB1' }}>
                                {
                                    Columns.map((Column) =>
                                        <TableCell key={Column.id} style={{ color: 'white', fontWeight: 'bolder' }}
                                            sortDirection={orderBy === Column.id ? order : false}
                                            onClick={() => handleRequestSort(Column.id)}>{Column.Name}</TableCell>
                                    )
                                }
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {props.UserState.Userlist &&
                                props.UserState.Userlist
                                    .slice(page * rowperpage, page * rowperpage + rowperpage)
                                    .map((user, i) => {
                                        return (
                                            <TableRow key={i}>
                                                <TableCell>{user.userId}</TableCell>
                                                <TableCell>{user.userName}</TableCell>
                                                <TableCell>{user.roleName}</TableCell>
                                                <TableCell>{user.userPhone}</TableCell>
                                                <TableCell>{user.userEmail}</TableCell>

                                                <TableCell>

                                                    <Button onClick={e => { handleEdit(user.userId) }} variant="contained" color="primary">Edit</Button>


                                                </TableCell>

                                            </TableRow>
                                        )
                                    })
                            }
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[2, 5, 10, 20]}
                    rowsPerPage={rowperpage}
                    page={page}
                    count={20}
                    component={'div'}
                    onPageChange={handlepagechange}
                    onRowsPerPageChange={handlerowperpagechange}
                >

                </TablePagination>
            </div>
        </div>);
}

const mapStatetoProps = (state) => {
    return {
        UserState: state.userRed
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        GetUserList: () => dispatch(GetUserList()),

    }
}

export default connect(mapStatetoProps, mapDispatchtoProps)(UserList);
