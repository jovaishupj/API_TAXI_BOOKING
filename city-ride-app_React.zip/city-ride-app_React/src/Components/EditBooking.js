import { useEffect,useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { GetAllLocation,GetBookingByBookingID, UpdateUserBooking } from "../Redux/ActionCreator";
import { useNavigate, useParams } from "react-router-dom";

const EditBooking = (props) => {
    const dispatch = useDispatch();
    const navigate=useNavigate();
    const{id}=useParams();

    const [bookingId, setBookingId] = useState(0);
    const [bookingType, setBookingType] = useState("now");
    const [locationId, setLocationID] = useState('');
    const [pickupTime, setPickupTime] = useState('');
    const [userId, setUserId] = useState(2);
    const [status, setStatus] = useState('waiting');
    const [userDocument , setUserDocument] = useState("");

    useEffect(() => {
        props.GetAllPickupLocation();
        dispatch(GetBookingByBookingID(id))
        console.log(props.bookingstate.booking);
        setBookingId(props.bookingstate.booking.bookingId);
        setBookingType(props.bookingstate.booking.bookingType);
        setPickupTime(props.bookingstate.booking.pickupTime);
       // setStatus(props.bookingstate.booking.status);
        setLocationID(props.bookingstate.booking.locationId);
        setUserId(props.bookingstate.booking.userId);
        setUserDocument(props.bookingstate.booking.userDocument);

    }, [props.bookingstate.booking.bookingId]);

    const handleSubmit = (e) => {
        e.preventDefault(); 
        console.log({
            bookingType,
            locationId,
            pickupTime,
            userDocument,
            status
        });
        const formData = new FormData();
        formData.append('BookingId',bookingId);
      
        formData.append('status',status);
        dispatch(UpdateUserBooking(formData));
         
            navigate('/BookingList');
       
        };
        const handleStatusChange = (e) => {
            setStatus(e.target.value);
           
        };
    return (
        <div>

        <form className="container" onSubmit={handleSubmit}>
            <div className="row">
                <div className="offset-lg-2 col-lg-8 pt-4" >
                    <div className="card">
                        <div className="card-header">
                            <h4>Edit Booking</h4>
                        </div>
                        <div className="card-body">
                        <div className="form-group">
                                    <label>Booking Number</label>
                                    <input  disabled={true} value={bookingId} className="form-control"></input>
                                </div>
                            <div className="form-group" >
                                <label >Booking Type: <span className="text-danger">*</span></label><br />
                                <div className="form-check form-check-inline " style={{ float: 'left' }}>
                                    <input required
                                        className="form-check-input"
                                        type="radio"
                                        name="BookingType"
                                        value="now"
                                        checked={bookingType === 'now'}
                                        disabled={true} 
                                    />
                                    <label className="form-check-label">Now  <span className="text-danger">*</span></label>
                                </div>
                                <div className="form-check form-check-inline col-10 " style={{ float: 'left' }}>
                                    <input required
                                        className="form-check-input"
                                        type="radio"
                                        name="BookingType"
                                        value="later"
                                        checked={bookingType === 'later'}
                                        disabled={true} 
                                    />
                                    <label className="form-check-label">Later</label>
                                </div>
                            </div>
                            <div className="form-group ">
                                <label>Pickup Location:  <span className="text-danger">*</span></label>
                                <select required
                                    className="form-control"
                                    value={locationId}
                                    disabled={true} 
                                >
                                    <option value="">Select Location</option> 
                                    {
                                    props.bookingstate.LocationLst.map(location => 
                                    ( <option key={location.locationID}
                                     value={location.locationID}> {location.locationName}
                                      </option> ))}                               
                                </select>
                            </div>

                            <div className="form-group">
                                <label>Pickup Time:<span className="text-danger">*</span> </label>
                                <input required type="datetime-local" className="form-control" value={pickupTime}
                                  disabled={true}    />
                            </div>
                            {/* <div className="fo rm-group ">
                                <label >User Document: <span className="text-danger">*</span></label>
                                <input required
                                    type="file" accept=".jpeg,.jpg,.png,.pdf"
                                    className="form-control-file col-12"
                                    onChange={handleFileChange}
                                /> 

                            </div>*/}
                            <div className="form-group ">
                                <label>Status:<span className="text-danger">*</span></label>
                                <select required
                                    className="form-control"
                                    value={status}
                                    onChange={handleStatusChange}
                                >
                                    <option disabled={true} value="scheduled" >Scheduled</option>
                                    <option value="waiting">Waiting</option>
                                    <option value="cancelled">Cancelled</option>
                                </select>
                            </div>
                        </div>
                        <div className="card-footer">
                            <button className="btn btn-success" type="submit">Update</button>
                        </div>

                    </div>

                </div>
            </div>
        </form>
    </div>
     );
}
 
const mapStatetoProps = (state) => {
    return {
        bookingstate: state.booking
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        GetAllPickupLocation: () => dispatch(GetAllLocation())

    }
}


export default connect(mapStatetoProps, mapDispatchtoProps)(EditBooking);
