import { useEffect,useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { GetAllLocation,GetBookingByBookingID, RegisterNewUser, UpdateUserBooking, UserLogin } from "../Redux/ActionCreator";
import { useNavigate, useParams } from "react-router-dom";
import { clearSuccessMessage } from "../Redux/Action";

const LoginUser = (props) => {
    const [userName, setuserName] = useState('');
    const [isload, SetIsload] = useState(false);
    const [userPassword, setuserPassword] = useState(''); 
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleSubmit = async (e) => {
        e.preventDefault(); 
        const formData = new FormData();
        formData.append('UserName',userName);
        formData.append('userPassword',userPassword);
        dispatch( UserLogin(formData));
      
      
         
        };
        useEffect(() => {
            //localStorage.clear();
            if(props.userState.sucecessmessage==='LoginSucess')
            {
                console.log(props.userState);
            localStorage.setItem('Token',props.userState.Token);
            localStorage.setItem('UserName',props.userState.User.userName);
            localStorage.setItem('UserID',props.userState.User.userId);
            localStorage.setItem('Role',props.userState.UserRole.role.roleName);
            dispatch(clearSuccessMessage());
            navigate('/')
            }
           
              
        
        }, [props.userState.sucecessmessage,navigate,dispatch]);

const handleRegisterClick=()=>{
    navigate('/RegisterUser');
}
    return (
        <div>

            <form className="container" onSubmit={handleSubmit}>
                <div className="row">
                    <div className="offset-lg-2 col-lg-8 pt-4" >
                        <div className="card">
                            <div className="card-header">
                                <h4>Login</h4>
                            </div>
                            <div className="card-body">
                                <div className="form-group">
                                    <label>User Name <span className="text-danger">*</span> </label>
                                    <input  required className="form-control" value={userName} 
                                    onChange={(e) => setuserName(e.target.value)}></input>
                                </div>
                               
                                <div className="form-group">
                                    <label>Password  <span className="text-danger">*</span> </label>
                                    <input required type="password"  className="form-control" value={userPassword} 
                                    onChange={(e) => setuserPassword(e.target.value)}></input>
                                </div>
                            </div>
                            <div className="card-footer">
                                <button className="btn btn-success" type="submit">Login</button>
                                <button className="btn btn-primary" onClick={handleRegisterClick} type="button">Register</button>

                            </div>

                        </div>

                    </div>
                </div>
            </form>
        </div>
    );
}
const mapStatetoProps = (state) => {
    return {
        userState: state.userRed
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        RegisterNewUser: () => dispatch(RegisterNewUser())

    }
}
export default connect(mapStatetoProps, mapDispatchtoProps)(LoginUser);

