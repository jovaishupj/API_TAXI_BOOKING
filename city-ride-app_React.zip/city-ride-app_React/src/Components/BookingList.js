import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { connect, useDispatch } from 'react-redux';
import { DeleteUserBooking, GetAllBookingByUserID, GetAllLocation } from '../Redux/ActionCreator';
import { DataGrid } from '@mui/x-data-grid';
import { TextField, Button } from '@mui/material';

const BookingList = (props) => {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [isload, SetIsload] = useState(false);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(2);
    const [filterBookingId, setFilterBookingId] = useState('');
    const [filterDate, setFilterDate] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    
    useEffect(() => {
        let userid=localStorage.getItem('UserID');
    dispatch(GetAllBookingByUserID(userid));
    console.log(props.bookingstate.bookinglst)
    

}, [isload]);

    const handleEdit = (id) => {
        navigate('/EditBooking/' + id);
    };

    const handleDelete = (id) => {
        if (window.confirm('Do you want to delete this booking?')) {
            dispatch(DeleteUserBooking(id));
            let userid=localStorage.getItem('UserID');
            dispatch(GetAllBookingByUserID(userid));
            SetIsload(true);
        }
    };

    const handleFilterChange = (e) => {
        const { name, value } = e.target;
        if (name === 'bookingId') setFilterBookingId(value);
        if (name === 'creationDate') setFilterDate(value);
        if (name === 'status') setFilterStatus(value);
    };

    const filteredBookings = props.bookingstate.bookinglst.filter((book) => {
        const bookingIdMatch = book.bookingId.toString().includes(filterBookingId);
        const dateMatch = book.creationDate.includes(filterDate);
        const statusMatch = book.status.toLowerCase().includes(filterStatus.toLowerCase());

        return bookingIdMatch && dateMatch && statusMatch;
    });

    const columns = [
        { field: 'bookingId', headerName: 'Booking ID', width: 150 },
        { field: 'bookingType', headerName: 'Booking Type', width: 150 },
        { field: 'locationId', headerName: 'Location Name', width: 150 },
        { field: 'pickupTime', headerName: 'Pickup Time', width: 250 },
        { field: 'userDocument', headerName: 'User ID', width: 150 },
        { field: 'status', headerName: 'Status', width: 150 },
        { field: 'creationDate', headerName: 'Booking Date', width: 250 },
        {
            field: 'actions',
            headerName: 'Action',
            width: 200,
            renderCell: (params) => (
                <>
                    <Button
                        onClick={() => handleEdit(params.row.bookingId)}
                        variant="contained"
                        color="primary"
                    >
                        Edit
                    </Button>
                    <Button
                        onClick={() => handleDelete(params.row.bookingId)}
                        variant="contained"
                        color="error"
                        style={{ marginLeft: 10 }}
                    >
                        Delete
                    </Button>
                </>
            ),
        },
    ];

    return (
        <div className=" col-lg-12 pt-4">
            <div style={{ margin: '1%', borderStyle: 'outset' }}>
              
                <div style={{ width: '100%' }}>
                    <DataGrid
                        rows={filteredBookings}
                        columns={columns}
                        page={page}
                        pageSize={rowsPerPage}
                        rowsPerPageOptions={[2, 5, 10, 20]}
                        onPageChange={(newPage) => setPage(newPage)}
                        onPageSizeChange={(event) => {
                            setRowsPerPage(event.target.value);
                            setPage(0);
                        }}
                        
                        pagination
                        
                    
                        sortingOrder={['asc', 'desc']}
                        sortingMode="client"
                        getRowId={(row) => row.bookingId}
                    />
                </div>
            </div>
        </div>
    );
};

const mapStatetoProps = (state) => {
    return {
        bookingstate: state.booking
    };
};

const mapDispatchtoProps = (dispatch) => {
    return {
        GetAllBookingByID: () => dispatch(GetAllBookingByUserID()),
        GetAllPickupLocation: () => dispatch(GetAllLocation())
    };
};

export default connect(mapStatetoProps, mapDispatchtoProps)(BookingList);
