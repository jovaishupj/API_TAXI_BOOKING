import { useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { UpdateUserAccess } from "../Redux/ActionCreator";
import { clearSuccessMessage } from "../Redux/Action";
const EditUser = (props) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { userId } = useParams();
    const [User, setUser] = useState('');
    const [selectedRole, setSelectedRole] = useState(1);
   
    const roles = [
        { roleId: 1, roleName: 'admin' },
        { roleId: 2, roleName: 'Customer' }
    ];
    const handleRoleChange = (e) => {
        setSelectedRole(e.target.value);      
    };

const handleSubmit=(e)=>{
    e.preventDefault(); 
    const formData = new FormData();
        formData.append('userId',userId);
      
        formData.append('roleId',selectedRole);
        dispatch(UpdateUserAccess(formData));
        navigate('/UserList');
       
}
   

    return (
        <div>

            <form className="container" onSubmit={handleSubmit}>
                <div className="row">
                    <div className="offset-lg-2 col-lg-8 pt-4" >
                        <div className="card">
                            <div className="card-header">
                                <h4>Edit User Access</h4>
                            </div>
                            <div className="card-body">
                                <div className="form-group">
                                    <label>User ID</label>
                                    <input disabled={true} value={userId} className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label>Role</label>
                                    <select onChange={handleRoleChange} value={selectedRole} className="form-control">
                                        {roles.map(role => (
                                            <option key={role.roleId} value={role.roleId}>
                                                {role.roleName}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                            </div>
                            <div className="card-footer">
                                <button className="btn btn-success" type="submit">Update</button>
                            </div>

                        </div>

                    </div>
                </div>
            </form>
        </div>
    );
}
const mapStatetoProps = (state) => {
    return {
        UserState: state.userRed
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        UpdateUserAccess: () => dispatch(UpdateUserAccess()),

    }
}

export default connect(mapStatetoProps, mapDispatchtoProps)(EditUser);
