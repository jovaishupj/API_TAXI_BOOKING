import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from 'react-toastify'
import { connect,useDispatch } from "react-redux";
import axios from "axios";
import { GetAllLocation,CreateUserBooking, FileUpload } from "../Redux/ActionCreator";


const Booking = (props) => {
    const [BookingId, setBookingId] = useState(0);
    const [BookingType, setBookingType] = useState("");
    const [LocationId, setLocationID] = useState('');
    const [PickupTime, setPickupTime] = useState('');
    const [UserId, setUserId] = useState(3);
    const [UserDocumentFile, setUserDocumentFile] = useState(null);
    const [UserDocument , setUserDocument] = useState("");
    const [status, setStatus] = useState('schedule');
    const [minTime, setMinTime] = useState("");
    const [maxTime, setMaxTime] = useState("");
    const [error, setError] = useState("");

    const navigate = useNavigate();
    const dispatch = useDispatch();
    useEffect(() => {
        props.GetAllPickupLocation();
        console.log("Booking lsit"+props.bookingstate.LocationLst);
        if (BookingType === "now") {
            const now = new Date();
            const maxValidTime = new Date(now.getTime() + 60 * 60000);
            console.log(maxValidTime);

            const convertToGST = (date) => {
                const options = { timeZone: 'Asia/Dubai', hour12: false };
                return new Date(date.toLocaleString('en-US', options));
            }
            const formatForDateTimeLocal = (date) => {
                const offset = date.getTimezoneOffset() * 60000;
                const localISOTime = (new Date(date.getTime() - offset)).toISOString().slice(0, 16);
                return localISOTime;
            }

            const nowGST = convertToGST(now);
            const maxTimeGST = convertToGST(maxValidTime);
            setMinTime(formatForDateTimeLocal(nowGST));
            setMaxTime(formatForDateTimeLocal(maxTimeGST));
            console.log(maxTimeGST);
        } else {
            setMinTime("");
            setMaxTime("");
        }
    }, [BookingId]);

    const handleSubmit = (e) => {
        e.preventDefault();
        const _obj = { BookingType,UserId, LocationId,PickupTime,UserDocument,status };
        console.log({
            BookingType,
            LocationId,
            PickupTime,
            UserDocumentFile,
            UserDocument,
            status
        });
        const formData = new FormData();
        
       const formFileData = new FormData();
        formFileData.append('UserDocumentFile', UserDocumentFile);
        dispatch(FileUpload(formFileData));
        if(props.bookingstate.DocumentName.length>0)
        {
            let userid=localStorage.getItem('UserID');
        formData.append('BookingType',BookingType);
        formData.append('UserDocument',props.bookingstate.DocumentName);
        formData.append('UserId',userid);
        formData.append('LocationId',LocationId);
        formData.append('PickupTime',PickupTime);
        formData.append('status',status);
       
        dispatch(CreateUserBooking(formData));
         if(props.bookingstate.sucecessmessage.length>0)
         {setBookingId(props.bookingstate.booking.bookingId);
            navigate('/BookingConfirmation');
         }
        
        }
       };
       
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const validExtensions = ["jpeg", "jpg", "png", "pdf"];
            const fileExtension = file.name.split(".").pop().toLowerCase();
            if (validExtensions.includes(fileExtension)) {
                setUserDocument(file.name);
                setUserDocumentFile(file);
                setError("");
            } else {
                setUserDocument(null);
                setUserDocumentFile("");
                setError("Invalid file type. Please upload a JPEG, PNG, or PDF file.");
            }
        }
    };

    return (
        <div>

            <form className="container" onSubmit={handleSubmit}>
                <div className="row">
                    <div className="offset-lg-2 col-lg-8 pt-4" >
                        <div className="card">
                            <div className="card-header">
                                <h4>Book Your Next Ride With US</h4>
                            </div>
                            <div className="card-body">
                                <div className="form-group" >
                                    <label >Booking Type: <span className="text-danger">*</span></label><br />
                                    <div className="form-check form-check-inline " style={{ float: 'left' }}>
                                        <input required
                                            className="form-check-input"
                                            type="radio"
                                            name="BookingType"
                                            value="now"
                                            checked={BookingType === 'now'}
                                            onChange={(e) => setBookingType(e.target.value)}
                                        />
                                        <label className="form-check-label">Now  <span className="text-danger">*</span></label>
                                    </div>
                                    <div className="form-check form-check-inline col-10 " style={{ float: 'left' }}>
                                        <input required
                                            className="form-check-input"
                                            type="radio"
                                            name="BookingType"
                                            value="later"
                                            checked={BookingType === 'later'}
                                            onChange={(e) => setBookingType(e.target.value)}
                                        />
                                        <label className="form-check-label">Later</label>
                                    </div>
                                </div>
                                <div className="form-group ">
                                    <label>Pickup Location:  <span className="text-danger">*</span></label>
                                    <select required
                                        className="form-control"
                                        value={LocationId}
                                        onChange={(e) => setLocationID(e.target.value)}
                                    >
                                        <option value="">Select Location</option> 
                                        {
                                        props.bookingstate.LocationLst.map(location => 
                                        ( <option key={location.locationID}
                                         value={location.locationID}> {location.locationName}
                                          </option> ))}                               
                                    </select>
                                </div>

                                <div className="form-group">
                                    <label>Pickup Time:<span className="text-danger">*</span> </label>
                                    <input required type="datetime-local" className="form-control" value={PickupTime}
                                        onChange={(e) => setPickupTime(e.target.value)} min={minTime} max={maxTime} disabled={BookingType !== "now" && BookingType !== "later"} />
                                </div>
                                <div className="form-group ">
                                    <label >User Document: <span className="text-danger">*</span></label>
                                    <input required
                                        type="file" accept=".jpeg,.jpg,.png,.pdf"
                                        className="form-control-file col-12"
                                        onChange={handleFileChange}
                                    />

                                </div>
                                <div className="form-group ">
                                    <label>Status:<span className="text-danger">*</span></label>
                                    <select required
                                        className="form-control"
                                        value={status}
                                        onChange={(e) => setStatus(e.target.value)}
                                    >
                                        <option value="scheduled">Scheduled</option>
                                        <option value="waiting">Waiting</option>
                                    </select>
                                </div>
                            </div>
                            <div className="card-footer">
                                {error && <p className="text-danger">{error}</p>}
                                <button className="btn btn-success" type="submit">Book Ride</button>
                            </div>

                        </div>

                    </div>
                </div>
            </form>
        </div>
    );
}


const mapStatetoProps = (state) => {
    return {
        bookingstate:state.booking
    }
}

const mapDispatchtoProps = (dispatch) => {
    return {
        GetAllPickupLocation:()=> dispatch(GetAllLocation())
        
    }
}


export default connect(mapStatetoProps, mapDispatchtoProps)(Booking);
