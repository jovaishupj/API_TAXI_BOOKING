import axios from "axios";
import { GetAllBookingFail,GetAllLocation_Suc, GetAllBookingSucess,CreateBooking, makeRequest, UploadDocument, UpdateBooking, GetBookingByID, RemoveBooking, Login, EditUser, AddUser, getAllUsers } from "./Action"
import { toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";
import { createAsyncThunk } from '@reduxjs/toolkit';

export const GetAllBookingByUserID=(userid)=>{
    return(dispatch)=>{
        dispatch(makeRequest);
        axios.get("https://localhost:7263/api/Booking/GetAllBookingByUserID?UserId="+userid)
        .then(res=>{
         const obj=res.data;
         dispatch(GetAllBookingSucess(obj));
        }).catch(err=>{
            toast.error('Failed to Booking data')
        });
    }
}
export const GetUserList=()=>{
    return(dispatch)=>{
        dispatch(makeRequest);
        axios.get("https://localhost:7263/api/User/GetUserRoleList")
        .then(res=>{
         const obj=res.data;
       
         dispatch(getAllUsers(obj));
        // toast.success('User List Successfully')
        }).catch(err=>{
            toast.error('Failed to User List data')
        });
    }
}

export const GetAllLocation=()=>{
    return(dispatch)=>{
        axios.get("https://localhost:7263/api/Booking/GetAllLocation")
        .then(res=>{
         const obj=res.data;
         //console.log(obj);
         dispatch(GetAllLocation_Suc(obj));
         //toast.success(obj);
       
        }).catch(err=>{
            toast.error('Failed to load Location data')
        });
    }
}
export const CreateUserBooking = (data) => {

    return (dispatch) => {
        dispatch(makeRequest);
        axios.post("https://localhost:7263/api/Booking/CreateBooking", data).then(res => {
            dispatch(CreateBooking(res.data));

       toast.success('Booking Created Successfully')
        }).catch(err => {
            console.log(err.response.data);
            toast.error('Failed to Booking due to :' + err.response.data)
        });
    }
}

export const FileUpload = (data) => {
    return (dispatch) => {
        dispatch(makeRequest);
        axios.post("https://localhost:7263/api/Booking/FileUpload", data ,
            {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          })
        .then(res => {
            dispatch(UploadDocument(res.data));
            console.log('Uploaded successfully.')
        }).catch(err => {
            toast.error('Failed Upload due to :' + err.response.data)
        });
    }
}

export const UpdateUserBooking = (data) => {
    return (dispatch) => {
        dispatch(makeRequest);
        axios.put("https://localhost:7263/api/Booking/UpdateBooking", data).then(res => {
            dispatch(UpdateBooking(res.data));
            toast.success('Booking updated Successfully')
        }).catch(err => {
            console.log(err.response.data);
            toast.error('Failed to Booking due to :' + err.response.data)
        });
    }
}
export const GetBookingByBookingID=(id)=>{
    return(dispatch)=>{
        dispatch(makeRequest);
        axios.get("https://localhost:7263/api/Booking/GetBookingByBookingID?BookingID="+id)
        .then(res=>{
         const obj=res.data;
         dispatch(GetBookingByID(obj));
        }).catch(err=>{
            toast.error('Failed to Booking data')
        });
    }
}
export const DeleteUserBooking = (id) => {
    return (dispatch) => {
        dispatch(makeRequest);
        axios.delete("https://localhost:7263/api/Booking/DeleteBooking?BookingID="+id).then(res => {
            dispatch(RemoveBooking(res.data));
            toast.success('Booking deleted Successfully')
        }).catch(err => {
            console.log(err.response.data);
            toast.error('Failed to Booking delete due to :' + err.response.data)
        });
    }
}

export const RegisterNewUser = (data) => {

    return (dispatch) => {

        axios.post("https://localhost:7263/api/User/RegisterUser", data).then(res => {
            dispatch(AddUser());
            toast.success('User Created Successfully')
        }).catch(err => {
            console.log(err.message);
            toast.error('Failed to Register User');
        });
    }
}
export const UserLogin = (data) => {
    return async (dispatch) => {
        
        await axios.post("https://localhost:7263/api/User/Login", data).then(res => {
            dispatch(Login(res.data));
            toast.success(' Welcome')
        }).catch(err => {
            console.log(err.response.data);
            toast.error('Failed to Register User due to :' + err.response.data);
        });
    }
}
export const UpdateUserAccess = (data) => {
    return (dispatch) => {
        
        axios.post("https://localhost:7263/api/User/UpdateUser", data).then(res => {
            dispatch(EditUser(res.data));
            toast.success('Updated')
        }).catch(err => {
            console.log(err.response.data);
            toast.error('Failed to update User due to :' + err.response.data);
        });
    }
}