import { CLEAR_MESSAGE, CREATE_BOOKING_SUCCESS, EDIT_USER_SUCCESS, FAIL, GET_BOOKING_BY_ID, GetAllLOCATION_SUCCESS, GETALLUSERS, LOGIN_USER_SUCCESS, MAKEREQUEST, REGISTER_USER_SUCCESS, REMOVE_BOOKING_BY_ID, SUCCESS, UPDATE_BOOKING_SUCCESS, UPLOAD_DOC_SUCCESS } from "./ActionType"

export const initialstate = {
    isloading: false,
    bookinglst: [],
    booking: {},
    sucecessmessage: '',
    errormessage: '',
    LocationLst: [],
    DocumentName: ""
}

export const UserIniState = {
    User: {},
    Userlist: [],
    Token: "",
    UserRole: ""
}

export const UserReducer = (state = initialstate, action) => {
    switch (action.type) {
        case REGISTER_USER_SUCCESS:
            return {
                ...state,
                sucecessmessage: 'UserAdded',
            }
        case LOGIN_USER_SUCCESS:
            return {
                ...state,
                sucecessmessage: 'LoginSucess',
                User: action.payload.user,
                Token: action.payload.token,
                UserRole: action.payload.userRole,
            }
        case GETALLUSERS:
            return {
                ...state,
                Userlist: action.payload,
                sucecessmessage:''
            }

        case EDIT_USER_SUCCESS:
            return {
                ...state,
                sucecessmessage: 'EditSucess',
            }
        case CLEAR_MESSAGE:
            return {
                ...state,
                sucecessmessage: '',

            };
        default: return state;
    }
}

export const BookingReducer = (state = initialstate, action) => {
    switch (action.type) {
        case MAKEREQUEST:
            return {
                ...state,
                isloading: true,
                DocumentName: "",
                sucecessmessage: ""
            }
        case SUCCESS:
            return {
                ...state,
                isloading: false,
                bookinglst: action.payload
            }
        case FAIL:
            return {
                ...state,
                isloading: false,
                bookinglst: [],
                errormessage: action.payload
            }
        case GetAllLOCATION_SUCCESS:
            return {
                ...state,
                LocationLst: action.payload,
            }
        case CREATE_BOOKING_SUCCESS:

            return {
                ...state,
                sucecessmessage: 'Added',
                booking: action.payload
            }
        case UPDATE_BOOKING_SUCCESS:
            return {
                ...state,
                sucecessmessage: 'Updated',
                booking: action.payload
            }

        case UPLOAD_DOC_SUCCESS:
            return {
                ...state,
                DocumentName: action.payload,
            }
        case GET_BOOKING_BY_ID:
            return {
                ...state,
                booking: action.payload,
            }
        case REMOVE_BOOKING_BY_ID:
            return {
                ...state,
                sucecessmessage: 'Deleted',
                booking: action.payload
            }

        default: return state;
    }
}

