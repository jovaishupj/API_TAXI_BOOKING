import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { BookingReducer,UserReducer } from "./Reducer";
import { thunk } from "redux-thunk";
import {logger} from "redux-logger";

const rootreducer=combineReducers({booking:BookingReducer,userRed:UserReducer})
const Appstore = configureStore({
    reducer: rootreducer,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware().concat(thunk,logger)});
  
export default Appstore