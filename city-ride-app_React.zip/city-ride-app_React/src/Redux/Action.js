import { CLEAR_MESSAGE, CREATE_BOOKING_FAIL, CREATE_BOOKING_SUCCESS, EDIT_USER_SUCCESS, FAIL, GET_BOOKING_BY_ID, GetAllLOCATION_SUCCESS,
     GETALLUSERS,
     LOGIN_USER_SUCCESS,
     MAKEREQUEST, REGISTER_USER_SUCCESS, REMOVE_BOOKING_BY_ID, SUCCESS, UPDATE_BOOKING_SUCCESS, UPLOAD_DOC_SUCCESS } from "./ActionType"

export const makeRequest=()=>{
   return{
    type:MAKEREQUEST
   } 
}

export const GetAllBookingSucess=(data)=>{
    return{
        type:SUCCESS,
        payload:data
    }
}

export const GetAllBookingFail=(err)=>{
    return{
        type:FAIL,
        payload:err
    }
}
export const GetAllLocation_Suc=(data)=>{
    return{
        type:GetAllLOCATION_SUCCESS,
        payload:data
        
    }
}
export const CreateBooking=(data)=>{
    return{
        type:CREATE_BOOKING_SUCCESS,
        payload:data
    }
}
export const UpdateBooking=(data)=>{
    return{
        type:UPDATE_BOOKING_SUCCESS,
        payload:data
    }
}

export const UploadDocument=(data)=>{
    return{
        type:UPLOAD_DOC_SUCCESS,
        payload:data
        
    }
}

export const GetBookingByID=(data)=>{
    return{
        type:GET_BOOKING_BY_ID,
        payload:data
        
    }
}
export const RemoveBooking=(data)=>{
    return{
        type:REMOVE_BOOKING_BY_ID,
        payload:data
        
    }
}
export const AddUser=()=>{
    return{
        type:REGISTER_USER_SUCCESS
        
    }
}
export const EditUser=(data)=>{
    return{
        type:EDIT_USER_SUCCESS,
        payload:data
        
    }
}
export const Login=(data)=>{
    return{
        type:LOGIN_USER_SUCCESS,
        payload:data
        
    }
}

export const clearSuccessMessage = () => ({
    type: CLEAR_MESSAGE,
});

export const getAllUsers=(data)=>{
    return{
        type:GETALLUSERS,
        payload:data
        
    }
}