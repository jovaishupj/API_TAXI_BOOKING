﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Taxi_Booking.DTO;
using TaxiBooking.DataAccess;
using TaxiBooking.DataAccess.Repository;
using TaxiBooking.DataAccess.Repository.IRepository;
using TaxiBooking.Models;

namespace Taxi_Booking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        ApplicationDbContext context;
        private string _secretKey = "";
        private string _issuer = "";
        private string _audience = "";
        private IConfiguration configuration;
        IUnitOfWork unitOfWork;
        IMapper mapper;
        public UserController(ApplicationDbContext dbContext, IUnitOfWork _unitOfWork,IMapper _mapper, IConfiguration _config) 
        {
           context = dbContext;
            unitOfWork = _unitOfWork;
            mapper = _mapper;
            configuration = _config;
        }

        [HttpPost]
        [Route("RegisterUser")]
        public IActionResult RegisterUser([FromForm] RegisterUserDTO userDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var obj = unitOfWork.UserRepository.Get(u=>u.UserName == userDTO.UserName);
            if (obj != null) {
                return BadRequest("User Already Exist");
            }
            var user = mapper.Map<User>(userDTO);

            unitOfWork.UserRepository.Add(user);
            unitOfWork.UserRepository.Save();
            return Ok();
        }

        [HttpPost]
        [Route("Login")]
        public IActionResult UserLogin([FromForm] LoginDTO loginDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var obj = unitOfWork.UserRepository.Get(u => u.UserName == loginDTO.UserName);
            if (obj == null)
            {
                return BadRequest("User Not Exist. Please Register");
            }
            else if(obj.UserPassword!=loginDTO.UserPassword)
            {
                return BadRequest("Incorrect Password");
            }
            else if(obj.IsActive==0)
            {
                return BadRequest("User is InActive Status. Please Contact Administrator");
            }
            _issuer = configuration["Jwt:Iss"];
            _audience = configuration["Jwt:Aud"];
            _secretKey = configuration["Jwt:Key"];

            var claims = new[]
                {
                    new Claim(ClaimTypes.GivenName,obj.UserName),
                    new Claim(ClaimTypes.Email,obj.UserEmail)
                };


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _issuer,
                audience: _audience,
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            var tokenHandler = new JwtSecurityTokenHandler();
            var stringToken = tokenHandler.WriteToken(token);
            var userRole = unitOfWork.UserRoleRepository.Get(o => o.UserId == obj.UserId, "Role");

            return Ok(new { Token = stringToken,User=obj,UserRole=userRole});

        }
        
        [HttpGet]
        [Route("GetUserRoleList")]
        public IActionResult GetUserRoleList()
        {
            List<UserRoleAccess> users = new List<UserRoleAccess>();
            users=unitOfWork.UserRoleRepository.GetAll(null, "Role,User").ToList();
            List <UserRoleDTO> userRoleDto=new List<UserRoleDTO>();
            foreach (UserRoleAccess user in users)
            {
                var Dto = mapper.Map<UserRoleDTO>(user.User);
                Dto.RoleName = user.Role.RoleName;
                Dto.RoleId= user.Role.RoleId;
             
                userRoleDto.Add(Dto);
            }
            
            return Ok(userRoleDto);

        }

        [HttpPost]
        [Route("UpdateUser")]
        public IActionResult UpdateUser([FromForm] UserAccessDTO accessDTO)
        {
       

           var userAccess = unitOfWork.UserRoleRepository.Get(o => o.UserId == accessDTO.UserId);
            if(userAccess==null)
            {
                userAccess = new UserRoleAccess();
                userAccess.UserId = accessDTO.UserId;
                userAccess.RoleId = accessDTO.RoleID;
                unitOfWork.UserRoleRepository.Add(userAccess);

            }
            else
            {
                userAccess.RoleId = accessDTO.RoleID;
                unitOfWork.UserRoleRepository.Update(userAccess);


            }
            unitOfWork.UserRoleRepository.Save();
            return Ok();
        }

        [HttpGet]
        [Route("GetAllRole")]
        public IActionResult GetAllRole(int RoleId)
        {
            var role=unitOfWork.RoleRepository.GetAll();
            return Ok(role);
        }
      
        [HttpGet]
        [Route("GetUserRoleById")]
        public IActionResult GetUserRoleById(int UserId)
        {

            return Ok(unitOfWork.UserRoleRepository.Get(u => u.UserId == UserId));

        }

        [HttpGet]
        [Route("GetUserById")]
        public IActionResult GetUserById(int UserId)
        {
            return Ok(unitOfWork.UserRepository.Get(u => u.UserId == UserId));
        }
    }
}
