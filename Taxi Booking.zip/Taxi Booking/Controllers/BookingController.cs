﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxiBooking.DataAccess.Repository;
using TaxiBooking.DataAccess;
using TaxiBooking.Models;
using Taxi_Booking.DTO;
using Microsoft.EntityFrameworkCore;

namespace Taxi_Booking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        ApplicationDbContext context;
        IUnitOfWork unitOfWork;
        IMapper mapper;
        public BookingController(ApplicationDbContext dbContext, IUnitOfWork _unitOfWork, IMapper _mapper)
        {
            context = dbContext;
            unitOfWork = _unitOfWork;
            mapper = _mapper;
        }
        
        [HttpGet]
        [Route("GetAllLocation")]
        public IActionResult GetAllLocation()
        {
            return Ok(unitOfWork.LocationRepository.GetAll());
        }
        [HttpGet]
        [Route("GetAllLocationByID")]
        public IActionResult GetAllLocationByID(int Id)
        {
            return Ok(unitOfWork.LocationRepository.Get(l=>l.LocationID==Id));
        }

        [HttpGet]
        [Route("GetAllBooking")]
        public IActionResult GetAllBooking()
        {
            return Ok(unitOfWork.BookingRepository.GetAll(null, "Location"));
        }
        [HttpGet]
        [Route("GetAllBookingByUserID")]
        public IActionResult GetAllBookingByUserID(int UserId)
        {
            return Ok(unitOfWork.BookingRepository.GetAll(l => l.UserId == UserId, "Location"));
        }

        [HttpGet]
        [Route("GetBookingByUserID")]
        public IActionResult GetBookingByUserID(int UserId)
        {
            return Ok(unitOfWork.BookingRepository.Get(l => l.UserId == UserId, "Location"));
        }
        [HttpGet]
        [Route("GetBookingByBookingID")]
        public IActionResult GetBookingByBookingID(int BookingID)
        {
            return Ok(unitOfWork.BookingRepository.Get(l => l.BookingId == BookingID, "Location"));
        }

        [HttpPost]
        [Route("CreateBooking")]
        public IActionResult CreateBooking([FromForm] BookingsDTO bookingsDTO)
        {
           
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (!unitOfWork.BookingRepository.IsValidBooking(bookingsDTO.UserId))
            {
                return BadRequest("Booking cannot exceeds max allowed count of 5 per hour. Please try after sometime");
            }
     
            var obj = mapper.Map<Booking>(bookingsDTO);

            unitOfWork.BookingRepository.Add(obj);
            unitOfWork.BookingRepository.Save();
           var lastBooking =unitOfWork.BookingRepository.GetAll(l => l.UserId == bookingsDTO.UserId, "Location")
               .OrderByDescending(b => b.CreationDate).FirstOrDefault();


            return Ok(lastBooking);
        }

        [HttpPost]
        [Route("FileUpload")]
        public IActionResult FileUpload(IFormFile UserDocumentFile)
        {

            string directoryPath = @"C:\MyNewFolder";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);

            }
            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(UserDocumentFile.FileName);
            var filePath = Path.Combine(directoryPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                UserDocumentFile.CopyToAsync(stream);
            }
            return Ok(fileName);
        }


        [HttpPut]
        [Route("UpdateBooking")]
        public IActionResult UpdateBooking([FromForm] EditBookingDTO editBookingDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var booking=  unitOfWork.BookingRepository.Get(l => l.BookingId == editBookingDTO.BookingId, "Location");
            booking.status = editBookingDTO.status;

          //  var obj = mapper.Map<Booking>(editBookingDTO);

            unitOfWork.BookingRepository.Update(booking);
            unitOfWork.BookingRepository.Save();
            return Ok(booking);
        }


        [HttpDelete]
        [Route("DeleteBooking")]
        public IActionResult DeleteBooking(int bookingId)
        {
            var booking = unitOfWork.BookingRepository.Get(b => b.BookingId == bookingId);
            unitOfWork.BookingRepository.Remove(booking);
            unitOfWork.BookingRepository.Save();
            return Ok(booking);
        }
    }
}
