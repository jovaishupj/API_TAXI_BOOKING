﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using TaxiBooking.Models;

namespace Taxi_Booking.DTO
{
    public class BookingsDTO
    {
  
       
        public string BookingType { get; set; }
        [Required]
        public int LocationId { get; set; }
       
        [Required]
        public DateTime PickupTime { get; set; }
        [Required]
        public int UserId { get; set; }
        
        public string UserDocument { get; set; }
        [Required]
        public string status { get; set; } = "Scheduled";
        [Required]
        public DateTime CreationDate { get; set; } = DateTime.Now;
        [Required]
        public DateTime LastModifiedDate { get; set; } = DateTime.Now;
    }
}
