﻿using System.ComponentModel.DataAnnotations;

namespace Taxi_Booking.DTO
{
    public class EditBookingDTO
    {
        [Required]
        public int BookingId { get; set; }

        
        [Required]
        public string status { get; set; } = "Scheduled";
       
        [Required]
        public DateTime LastModifiedDate { get; set; } = DateTime.Now;
    }
}
