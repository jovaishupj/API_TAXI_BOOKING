﻿using System.ComponentModel.DataAnnotations;

namespace Taxi_Booking.DTO
{
    public class UserAccessDTO
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public int RoleID {  get; set; }

    }
}
