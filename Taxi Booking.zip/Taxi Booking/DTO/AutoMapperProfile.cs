﻿using AutoMapper;
using Taxi_Booking.DTO;
using TaxiBooking.Models;

namespace Taxi_Booking.DTO
{
    public class AutoMapperProfile: Profile
    {
        public AutoMapperProfile() { 
        CreateMap<User,RegisterUserDTO>().ReverseMap();
            CreateMap<User, LoginDTO>();
            CreateMap<Booking, BookingsDTO>().ReverseMap();
            CreateMap<Booking, EditBookingDTO>().ReverseMap();

            CreateMap<User, UserRoleDTO>()
             .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.UserId))
             .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.UserName))
             .ForMember(dest => dest.UserEmail, opt => opt.MapFrom(src => src.UserEmail))
             .ForMember(dest => dest.UserPhone, opt => opt.MapFrom(src => src.UserPhone))
             .ForMember(dest => dest.RoleId, opt => opt.Ignore())
             .ForMember(dest => dest.RoleName, opt => opt.Ignore());

            CreateMap<Role, UserRoleDTO>()
                .ForMember(dest => dest.RoleId, opt => opt.MapFrom(src => src.RoleId))
                .ForMember(dest => dest.RoleName, opt => opt.MapFrom(src => src.RoleName))
                .ForMember(dest => dest.UserId, opt => opt.Ignore())
                .ForMember(dest => dest.UserName, opt => opt.Ignore())
                .ForMember(dest => dest.UserEmail, opt => opt.Ignore())
                .ForMember(dest => dest.UserPhone, opt => opt.Ignore());
        }
    }
}
