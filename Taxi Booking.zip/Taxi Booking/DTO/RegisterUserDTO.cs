﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Taxi_Booking.DTO
{
    public class RegisterUserDTO
    {
       
        [Required]
        public string UserName { get; set; }
        [Required]
        [EmailAddress]
        public string UserEmail { get; set; }
        [Required]
        public int UserPhone { get; set; }
        [Required]
        [MinLength(8, ErrorMessage = "Password must be minimum 8 Character.")]
        public string UserPassword { get; set; }
        
    }
}
