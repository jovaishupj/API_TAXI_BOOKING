﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using TaxiBooking.Models;

namespace Taxi_Booking.DTO
{
    public class UserRoleDTO
    {
    
        public int RoleId { get; set; }
        
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string RoleName { get; set; } = "Customer";
        public int UserPhone { get; set; }
      



    }
}
